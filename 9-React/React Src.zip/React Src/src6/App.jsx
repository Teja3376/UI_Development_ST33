import React from "react"
import Myfunction from "./Myfunction"

function App() {

  return (
    <>
    <Myfunction/>
    </>
  )
}

export default App
