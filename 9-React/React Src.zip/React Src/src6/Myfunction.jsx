import React from 'react'

function Myfunction  () {
  return (
    <div>This is My Myfunction</div>
  )
}

export default Myfunction