import { Component } from "react";
import Myname from "./Classcompnentown";


class App extends Component{
  render(){
    return(
      <>
      <h1>
        Welcome To React Class Components
      </h1>
      <App1></App1>
     <Myname></Myname>
      </>

    );
  }
}
class App1 extends Component{
  render(){
    return(
      <>
      <h1> subin app</h1>
      </>

    );
  }
}
export  default App