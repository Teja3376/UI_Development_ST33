import React from 'react'

function Myfunction() {
  return (
    <div>Myfunction</div>
  )
}
function Mydata (){
    return(
        <>
        Hello sir
        </>
    );
}
export {Mydata}
export default Myfunction