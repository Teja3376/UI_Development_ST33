import React from "react"
import { Mydata } from "./Myfunction"

function App() {
  return (
  <>
  <Mydata/>
  </>
  )
}

export default App
