

function App() {
  var fname = "Charan";
  var lname = "Teja";
  var age = 21;

  return (
    <>
    <h1>first namee : {fname}</h1>
    <h1>Last Name : {lname}</h1>
    <h1>Age : {age}</h1>
    </>
  )
}

export default App
