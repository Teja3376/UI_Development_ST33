import React from 'react'

function Myfunction2() {
    var city = "Bhimavaram"
  return (
   <>
     City : {city}
   </>
  )
}
export default Myfunction2