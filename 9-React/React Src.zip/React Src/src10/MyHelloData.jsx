import {Component} from 'react';
class MyHelloData extends Component {  
    render() {
      
     return(    
      <div className='MyHelloData'>
        <h3>Welcome to  MyHelloData class component with JSX file </h3>
      
      </div>
     );
    }}

    export default MyHelloData;